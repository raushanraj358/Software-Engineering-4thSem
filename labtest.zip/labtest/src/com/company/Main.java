package com.company;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.zip.CheckedOutputStream;

public class Main extends Application {
    Pane mainlayout;
    static ArrayList<Activity> aclist;
    static String pathanswer = "";
    public static void main(String[] args) {
        aclist = new ArrayList<>();
	    launch(args);
    }
    static void print(){
        for(Activity a:aclist){
            System.out.println(a.name + " " + a.dur + " "+ a.starttime + " " +a.finishtime);
        }
    }
    static Activity search(String name){

        for(int i=0;i<aclist.size();i++){
            if (aclist.get(i).name.equals(name)) return aclist.get(i);
        }
        return null;
    }
    static ArrayList<Activity> getpredecessor(String str){
        ArrayList <Activity> pred=new ArrayList<>();
        str = str.trim();
        if (!str.equals("-")){
            String names[] = str.split(",");
            for(String name:names) {
                pred.add(search(name));
            }
        }
        return pred;
    }
    static void deletename(String name){
        for(Activity A:aclist){
            if (A.name.compareTo(name)==0) {
                aclist.remove(A);
                return;
            }
        }
    }
    static int findmax(ArrayList <Activity> pred){
        int maxi=-1;
        for(Activity activity:pred){
            if (activity.finishtime > maxi){
                maxi = activity.finishtime;
            }
        }
        return maxi;
    }
    static void calculatetime(){
        for(Activity activity:aclist){
            if (activity.predecessor.size()==0){
                activity.starttime = 0;
                activity.finishtime = activity.dur;
            }else{
                int maxi = findmax(activity.predecessor);
                activity.starttime = maxi;
                activity.finishtime = activity.starttime + activity.dur;
            }
        }
    }
    static String findcriticalpath(ArrayList <Activity> tab){
        int maxi = -1;
        if (tab.size()==0) return "";
        Activity temp=null;
        for(Activity activity:tab){
            if (activity.finishtime > maxi){
                maxi = activity.finishtime;
                temp = activity;
            }
        }
        temp.iscritical = true;
        String prev = findcriticalpath(temp.predecessor);
        String current = prev + temp.name + "-";
        return current;
    }
    static String converttostring(ArrayList<Activity> al){
        String ppp="";
        if (al.size()==0) {
            ppp+="-";
            return ppp;
        }
        for(Activity a:al){
            ppp+=(a.name+",");
        }
        return ppp;
    }
    static ArrayList<Contents> filltable(){
        ArrayList <Contents> clist = new ArrayList<>();
        for(Activity a:aclist){
            String getpre = converttostring(a.predecessor);
            String pp="";
            if (a.iscritical==true) pp="*";
            else pp="";
            clist.add(new Contents(a.name,getpre,a.dur,a.starttime,a.finishtime,pp));
        }
        return clist;
    }
    public void setlayout(Stage stage){
        mainlayout = new Pane();
        Label title = new Label("CRITICAL PATH METHOD");
        title.setTranslateX(300);title.setTranslateY(5);
        title.setFont(new Font("Serif",30));

        Button b1 = new Button("ADD NEW ACTICITY");
        b1.setTranslateX(20);b1.setTranslateY(50);
        b1.setPrefSize(160,30);
        b1.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                TextInputDialog tx1 = new TextInputDialog("");
                tx1.setHeaderText("Enter Activity Name");
                tx1.showAndWait();
                String name = tx1.getResult();
                TextInputDialog tx2 = new TextInputDialog("");
                tx2.setHeaderText("Enter Predecessor seperated by comma");
                tx2.showAndWait();
                String pred = tx2.getResult();
                TextInputDialog tx3 = new TextInputDialog("");
                tx3.setHeaderText("Enter Duration");
                tx3.showAndWait();
                String dur = tx3.getResult();
                int duration = Integer.parseInt(dur);
                ArrayList <Activity> predlist = new ArrayList<>();
                predlist = getpredecessor(pred);
                aclist.add(new Activity(name,duration,predlist));
                print();
            }
        });


        Button b2 = new Button("REMOVE SELECTED ACTICITY");
        b2.setTranslateX(200);b2.setTranslateY(50);
        b2.setPrefSize(240,30);
        b2.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                TextInputDialog tx1 = new TextInputDialog("");
                tx1.setHeaderText("Enter Activity Name to Be Deleted");
                tx1.showAndWait();
                String name = tx1.getResult();
                deletename(name);
                print();
            }
        });
        TextField ans = new TextField();
        ans.setTranslateX(20);ans.setTranslateY(650);
        ans.setPrefSize(840,200);
        ans.setFont(new Font("Serif",20));

        TableView table = new TableView<>();
        table.setEditable(false);
        TableColumn<String,Contents> first = new TableColumn<>("ACTIVITY");
        first.setPrefWidth(140);
        first.setCellValueFactory(new PropertyValueFactory<>("Name"));

        TableColumn<String,Contents> second = new TableColumn<>("INTERMEDIATE PREDECESSOR");
        second.setPrefWidth(140);
        second.setCellValueFactory(new PropertyValueFactory<>("Predecessor"));

        TableColumn<Integer,Contents> third = new TableColumn<>("DURATION");
        third.setPrefWidth(120);
        third.setCellValueFactory(new PropertyValueFactory<>("Duration"));

        TableColumn<Integer,Contents> fourth = new TableColumn<>("START TIME");
        fourth.setPrefWidth(120);
        fourth.setCellValueFactory(new PropertyValueFactory<>("Starttime"));

        TableColumn<Integer,Contents> fifth = new TableColumn<>("COMPLETION TIME");
        fifth.setPrefWidth(120);
        fifth.setCellValueFactory(new PropertyValueFactory<>("Completiontime"));

        TableColumn<String,Contents> sixth = new TableColumn<>("CRITICAL PATH");
        sixth.setPrefWidth(160);
        sixth.setCellValueFactory(new PropertyValueFactory<>("Criticalpath"));

        table.getColumns().addAll(first,second,third,fourth,fifth,sixth);
        table.setTranslateX(20);table.setTranslateY(100);


        Button b4 = new Button("RESET");
        b4.setTranslateX(720);b4.setTranslateY(50);
        b4.setPrefSize(160,30);
        b4.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                aclist.clear();
                table.getItems().clear();
                System.out.println("table clear");
                print();
                ans.clear();

            }
        });

        Button b3 = new Button("EVALUATE");
        b3.setTranslateX(460);b3.setTranslateY(50);
        b3.setPrefSize(240,30);
        b3.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                calculatetime();
                print();
                String pathfind = findcriticalpath(aclist);
                ans.appendText(pathfind);
                ArrayList <Contents> clist;
                clist = filltable();
                for(Contents c:clist){
                    table.getItems().add(c);
                }
                table.refresh();

            }
        });

        mainlayout.getChildren().addAll(b1,title,b2,b3,b4,table,ans);
        mainlayout.setVisible(true);
    }
    public void start(Stage primaryStage){
        setlayout(primaryStage);
        Group root = new Group();
        root.getChildren().addAll(mainlayout);
        primaryStage.setScene(new Scene(root,900,900));
        primaryStage.setTitle("CRITICAL PATH METHOD");
        primaryStage.show();
    }
}
