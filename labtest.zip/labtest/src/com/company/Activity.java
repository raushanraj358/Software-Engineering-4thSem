package com.company;
import java.util.ArrayList;

public class Activity {
    String name;
    int dur,finishtime,starttime;
    ArrayList <Activity> predecessor;
    boolean iscritical;
    public Activity(String name, int dur, ArrayList<Activity> predecessor) {
        this.name = name;
        this.dur = dur;
        this.predecessor = predecessor;
        iscritical = false;
    }
}
