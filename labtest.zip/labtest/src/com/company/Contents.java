package com.company;

public class Contents {
    private String Name;
    private String Predecessor;
    private int Duration;
    private int Starttime;
    private int Completiontime;
    private String Criticalpath;
    Contents(String name,String predecessor,int dur,int st,int ct,String criticalpath){
        this.Name=name;
        this.Predecessor = predecessor;
        this.Duration = dur;
        this.Starttime = st;
        this.Completiontime = ct;
        this.Criticalpath = criticalpath;
    }

    public String getName() {
        return Name;
    }

    public String getPredecessor() {
        return Predecessor;
    }

    public int getDuration() {
        return Duration;
    }

    public int getStarttime() {
        return Starttime;
    }

    public int getCompletiontime() {
        return Completiontime;
    }

    public String getCriticalpath() {
        return Criticalpath;
    }
}
