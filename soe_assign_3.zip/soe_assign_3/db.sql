use assign_3;

create table if not exists Judge(
	email varchar(40),
	pass varchar(40),
	id varchar(40)
);
insert into Judge values("judge1@iiita.ac.in","pass1","Judge1");
insert into Judge values("judge2@iiita.ac.in","pass2","Judge2");
insert into Judge values("judge3@iiita.ac.in","pass3","Judge3");

create table if not exists Performance(
	id int(255) AUTO_INCREMENT PRIMARY KEY,
	members int,
	batch varchar(40),
	ptype varchar(40),
	Judge1 int default 0,
	Judge2 int default 0,
	Judge3 int default 0	
);
	
create table if not exists Marks(
	Pid int,
	Judge1 int,
	Judge2 int,
	Judge3 int
);

	 
