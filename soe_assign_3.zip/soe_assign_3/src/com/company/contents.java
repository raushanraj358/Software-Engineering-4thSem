package com.company;

import javafx.beans.property.StringProperty;

public class contents {
    private int Marks;
    private int Id;
    private int Members;
    private String Batch,Ptype;
    contents(int m,int i,int mem,String b,String p){
        this.Marks = m;
        this.Id = i;this.Members = mem;
        this.Batch = b;this.Ptype = p;
    }
    public int getMarks(){return this.Marks;}
    public int getId(){return this.Id;}
    public int getMembers(){return this.Members;}
    public String getBatch(){return this.Batch;}
    public String getPtype(){return this.Ptype;}
}
