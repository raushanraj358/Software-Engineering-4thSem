package com.company;
import javafx.application.Application;
import javafx.beans.property.StringProperty;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import javax.swing.*;
import javax.xml.crypto.dsig.spec.XSLTTransformParameterSpec;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Optional;

public class Main extends Application  {
    public static final String URL = "jdbc:mysql://localhost:3306/assign_3?useSSL=false";
    public static final String DRIVER = "com.mysql.jdbc.Driver";
    public static final String USERNAME = "debian-sys-maint";
    public static final String PSWD = "KpohHpUo0ERoxK8z";
    public static Connection con;
    public static String Judgeid;
    Pane pleft,padmin,pjudge,eventpane,judgepane;TableView  table;
    boolean validateJudge(String username,String pass){
        try{
            String query = "select id from Judge where email = ? and pass = ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1,username);
            pst.setString(2,pass);
            ResultSet rs  = pst.executeQuery();
            if (!rs.next()) return false;
            else return true;
        }catch (Exception e){
            System.out.println("inside validate Judge");
            return false;
        }
    }
    String getid(String username,String pass){
        try{
            String query = "select id from Judge where email = ? and pass = ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1,username);
            pst.setString(2,pass);
            ResultSet rs  = pst.executeQuery();
            rs.next();
            String ret = rs.getString(1);
            return ret;
        }catch (Exception e){
            System.out.println("inside getid");
            return "notvalid";
        }
    }

    public void setfirstpane(Stage stage){
        pleft = new Pane();
        pleft.setPrefHeight(900);
        pleft.setPrefWidth(300);
        pleft.setStyle("-fx-background-color: #002973");

        Button b1 = new Button("ADMIN");
        Button b2 = new Button("JUDGE");
        b1.setTranslateX(100);b2.setTranslateY(470);
        b1.setTranslateY(400);b2.setTranslateX(100);
        b1.setStyle("-fx-background-color: #d42803");
        b2.setStyle("-fx-background-color: #d42803");
        b1.setPrefSize(150,40);
        b2.setPrefSize(150,40);
        pleft.getChildren().addAll(b1,b2);


        b1.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                setAllrightfalse(stage);
                padmin.setVisible(true);
            }
        });
        b2.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                setAllrightfalse(stage);
                pjudge.setVisible(true);
            }
        });
    }
    public boolean addPerformance(int num,String batch,String ptype){
        try{
            String query = "insert into Performance(Id,Members,Batch,Ptype) values (?,?,?,?)";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1,null);
            pst.setInt(2,num);
            pst.setString(3,batch);
            pst.setString(4,ptype);
            pst.execute();
            return true;
        }catch (Exception e){
            System.out.println("inside addperformance");
            e.printStackTrace();
            return false;
        }
    }
    public void setevent(Stage stage){
        eventpane = new Pane();
        eventpane.setTranslateY(0);
        eventpane.setTranslateX(300);
        eventpane.setPrefHeight(900);
        eventpane.setPrefWidth(600);

        Label l1 = new Label("Number of Members "),l2 = new Label("Batch "),l3 = new Label("Performace Type ");
        l1.setTranslateX(75);l2.setTranslateX(75);l3.setTranslateX(75);
        l1.setTranslateY(400);l2.setTranslateY(450);l3.setTranslateY(500);
        l1.setFont(new Font("Verdana",17));
        l2.setFont(new Font("Verdana",17));
        l3.setFont(new Font("Verdana",17));

        TextField t1 = new TextField(),t2 = new TextField() , t3 = new TextField();
        t1.setTranslateX(300);t2.setTranslateX(300);t3.setTranslateX(300);
        t1.setTranslateY(400);t2.setTranslateY(450);t3.setTranslateY(500);

        Button b1 = new Button("SUBMIT");
        b1.setStyle("-fx-background-color:  #2fcf00");
        b1.setPrefSize(150,40);
        b1.setTranslateX(200);b1.setTranslateY(550);
        b1.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                int num = Integer.parseInt(t1.getText());
                String batch = t2.getText();
                String ptype = t3.getText();
                t1.setText("");
                t2.setText("");
                t3.setText("");
                if (addPerformance(num,batch,ptype)){
                    Alert a = new Alert(Alert.AlertType.INFORMATION);
                    a.setContentText("Successfully Added");
                    a.show();
                }
                setAllrightfalse(stage);
                padmin.setVisible(true);
            }
        });

        eventpane.getChildren().addAll(l1,l2,l3,t1,t2,t3,b1);

    }
    public void setadminpane(Stage stage){
        padmin = new Pane();
        padmin.setTranslateX(300);
        padmin.setTranslateY(0);
        padmin.setPrefWidth(600);
        padmin.setPrefHeight(900);

        Button b1 = new Button("ADD AN EVENT");
        b1.setTranslateX(250);b1.setTranslateY(430);
        b1.setPrefSize(150,40);
        b1.setStyle("-fx-background-color:#FFC300");
        b1.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                setAllrightfalse(stage);
                eventpane.setVisible(true);
            }
        });
        //b2.setTranslateX(250);b2.setTranslateY(500);

        padmin.getChildren().addAll(b1);
        padmin.setVisible(true);
    }
    public ArrayList<contents> filljudgetable(){
        ArrayList <contents> arr = new ArrayList<>();
        try{
            String query = "select * from Performance";
            PreparedStatement pst = con.prepareStatement(query);
            ResultSet rs = pst.executeQuery();

            while(rs.next()){

               if (Judgeid.equals("Judge1")) arr.add(new contents(rs.getInt(5),rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getString(4)));
                else if (Judgeid.equals("Judge2")) arr.add(new contents(rs.getInt(6),rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getString(4)));
                else if (Judgeid.equals("Judge3")) arr.add(new contents(rs.getInt(7),rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getString(4)));
            }
            return arr;
        }catch (Exception e){
            System.out.println("inside filljudgetable");
            e.printStackTrace();
            return arr;
        }
    }
    public void updatetable(Stage stage){
        ArrayList <contents> arr = filljudgetable();
        table.getItems().clear();
        for(contents s:arr)
            table.getItems().add(s);
        table.refresh();
    }
    public void setjudge(Stage stage){
        pjudge = new Pane();
        pjudge.setTranslateX(300);
        pjudge.setTranslateY(0);
        pjudge.setPrefWidth(600);
        pjudge.setPrefHeight(900);

        Label l1 = new Label("USERNAME");
        Label l2 = new Label("PASSWORD");
        l1.setTranslateX(150);l1.setTranslateY(400);
        l2.setTranslateX(150);l2.setTranslateY(450);
        l1.setFont(new Font("Verdana",17));
        l2.setFont(new Font("Verdana",17));
        TextField t1 = new TextField(); PasswordField t2 = new PasswordField();
        t1.setTranslateX(270);t1.setTranslateY(400);
        t2.setTranslateX(270);t2.setTranslateY(450);

        Button b1 = new Button("Login");
        b1.setStyle("-fx-background-color:#0dff40");
        b1.setPrefSize(150,40);
        b1.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                if (validateJudge(t1.getText(),t2.getText())){
                    Judgeid = getid(t1.getText(),t2.getText());
                    t1.setText("");t2.setText("");
                    setAllrightfalse(stage);
                    judgepane.setVisible(true);
                    updatetable(stage);
                }
                else{
                    t1.setText("");
                    t2.setText("");
                }
            }
        });
        b1.setTranslateX(270);b1.setTranslateY(500);
        pjudge.getChildren().addAll(l1,l2,t1,t2,b1);
        padmin.setVisible(true);
    }
    public void setJudgepane(Stage stage) {
        judgepane = new Pane();
        judgepane.setTranslateX(300);
        judgepane.setTranslateY(0);
        judgepane.setPrefWidth(600);
        judgepane.setPrefHeight(900);

        Label l1 = new Label("MARKS");
        l1.setTextFill(Color.web("#060083"));
        l1.setFont(new Font("Serif", 20));
        l1.setTranslateX(250);
        l1.setTranslateY(0);

        table = new TableView();
        table.setEditable(false);
        TableColumn<Integer, contents> first = new TableColumn("MARKS");
        first.setPrefWidth(120);
        first.setCellValueFactory(new PropertyValueFactory<>("Marks"));
        TableColumn<Integer, contents> second = new TableColumn("ID");
        second.setPrefWidth(120);
        second.setCellValueFactory(new PropertyValueFactory<>("Id"));
        TableColumn<Integer, contents> third = new TableColumn("MEMBERS");
        third.setPrefWidth(120);
        third.setCellValueFactory(new PropertyValueFactory<>("Members"));
        TableColumn<String, contents> fourth = new TableColumn("BATCH");
        fourth.setPrefWidth(120);
        fourth.setCellValueFactory(new PropertyValueFactory<>("Batch"));
        TableColumn<String, contents> fifth = new TableColumn("PTYPE");
        fifth.setPrefWidth(120);
        fifth.setCellValueFactory(new PropertyValueFactory<>("Ptype"));

        table.getColumns().addAll(first, second, third, fourth, fifth);

        table.setOnMouseClicked((MouseEvent Event) -> {
            if (Event.getButton().equals(MouseButton.PRIMARY) && Event.getClickCount() == 2) {
                contents temp = (contents) table.getSelectionModel().getSelectedItem();
                TextInputDialog tx = new TextInputDialog("0");
                Button b1 = new Button("OK");
                tx.setHeaderText("ENTER YOUR MARKS");
                //tx.getDialogPane().lookupButton(ButtonType.CANCEL).setDisable(false);
                Optional<String> result = tx.showAndWait();
                if (result.isPresent()) {
                    try {
                        String query = "update Performance set " + Judgeid + " = ? where id = ?";
                        PreparedStatement pst = con.prepareStatement(query);
                        pst.setInt(1, Integer.parseInt(tx.getResult()));
                        pst.setInt(2, temp.getId());
                        pst.execute();
                        updatetable(stage);
                    } catch (Exception e) {
                        System.out.println("inside set Judge Pane");
                        e.printStackTrace();
                    }
                }
                else{
                    tx.close();
                }
            }
        });

        Button b1 = new Button("LOGOUT");
        b1.setPrefSize(150,40);
        b1.setStyle("-fx-background-color: #e5b015");

        b1.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                Judgeid = "";
                judgepane.setVisible(false);
                pjudge.setVisible(true);
            }
        });

        b1.setTranslateX(225);
        VBox vbox = new VBox();
        vbox.setPrefWidth(600);
        vbox.setPrefHeight(900);name
        vbox.setSpacing(20);
        vbox.setPadding(new Insets(10, 0, 0, 0));
        vbox.getChildren().addAll(l1,table,b1);

        judgepane.getChildren().addAll(vbox);

    }
    public void setAllrightfalse(Stage stage){
        padmin.setVisible(false);
        pjudge.setVisible(false);
        eventpane.setVisible(false);
        judgepane.setVisible(false);
    }
    public void start(Stage primaryStage){
        setfirstpane(primaryStage);
        setadminpane(primaryStage);
        setJudgepane(primaryStage);
        setjudge(primaryStage);
        setevent(primaryStage);

        setAllrightfalse(primaryStage);

        pleft.setVisible(true);

        Group root = new Group();
        root.getChildren().addAll(pleft,padmin,pjudge,eventpane,judgepane);

        primaryStage.setResizable(false);
        primaryStage.setScene(new Scene(root,900,900));
        primaryStage.setTitle("Evaluation Portal");

        primaryStage.show();
    }
    public static void main(String[] args) {
        try{
            Class.forName(DRIVER);
            con = DriverManager.getConnection(URL,USERNAME,PSWD);
            System.out.println("Connection Succesfull");
            launch(args);
            con.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

}
