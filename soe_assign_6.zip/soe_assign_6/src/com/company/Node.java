package com.company;

public class Node {
    String s;
    int ln;
    int ob, cb;
    String type;

    Node(String s, int lno, int ob, int cb, String type) {
        this.s = s;
        this.ln = lno;
        this.ob = ob;
        this.cb = cb;
        this.type = type;
    }
}
