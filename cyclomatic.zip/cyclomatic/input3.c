include <stdio.h>

int fact(int a, int b) {
    if (z == 0) {
        if (y == 0) {
            if (x == 0 && a == 0 || b == 0)
        }
    }
}

int main()
{   
    int zy, y = 2;
    float c;
    double d = 32.5;
    printf("Hello, world\n");
    int c, d;
    char at, xif;
    if (x == y) {
        printf("True");
    }
    printf("while");
    doif();
    
    for (y = 0; y < 10; y++) {
        if (y == 0) {
            continue;
        }
    }
    return 0;
}

void function (int x, char whileat) 
{
    /* Do anything */
    int a, b;
    if (function) fucntion;
    switch (1) {
        case 1: 
        {
            anything
            break;
        }
        case 2: {
            nothing
            break;
        }
        default:anything
    }
}