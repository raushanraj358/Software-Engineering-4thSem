package cyclomatic;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
class Helper{
    public static String getInputFromFile(String Filename){
        String inputData = "";
        try{
            FileReader fr = new FileReader(Filename);
            BufferedReader br = new BufferedReader(fr);
            String input;
            while((input = br.readLine())!=null)
            {
                inputData += input + "\n";
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return inputData;
    }
    public static String removeQuotes(String inputData){
        String pattern = "\".*?\"";
        Pattern p = Pattern.compile(pattern,Pattern.DOTALL);
        Matcher m = p.matcher(inputData);
        inputData = m.replaceAll("");
        return inputData;
    }
    public static String removeSinglelinecomments(String inputData){
        String pattern = "//.*?\\n";
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(inputData);
        inputData = m.replaceAll("\n");
        return inputData;
    }
    public static String removeMultilinecomments(String inputData){
        String pattern = "/\\*.*?\\*/";
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(inputData);
        inputData = m.replaceAll("");
        return inputData;
    }
}
public class iit2017010_2 {
    static void run(String Filename)
    {
        String inputData = Helper.getInputFromFile(Filename);
        inputData = Helper.removeQuotes(inputData);
        inputData = Helper.removeSinglelinecomments(inputData);
        inputData = Helper.removeMultilinecomments(inputData);
        cyclo(inputData);
    }
    static void cyclo(String inputData){
        String pattern = "(void|int|long|char|double|float){1}\\s+(.*?)\\s*\\(.*?\\)\\s*\\{";
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(inputData);
        int i=1;
        int total = 0;
        while((m.find())){
            int openingIndex = m.end();
            int closingIndex = findMatching(inputData,openingIndex);
            int nodecisionPoints = findDecisionpoint(inputData.substring(openingIndex,closingIndex));
            System.out.println("Funcion " + m.group(2) + "(C" + i + "): " + nodecisionPoints + "+ 1 = "+(nodecisionPoints+1));
            total += nodecisionPoints+1;
            i++;
        }
        System.out.println("TC = " + total);
    }
    static int findDecisionpoint(String inputData){
        int count=0;

        String pattern = "\\b(if|while|for)\\b\\s*\\(.*\\)";
        count+=countOf(pattern,inputData);

        pattern = "(&&|\\|\\|)";
        count+=countOf(pattern,inputData);

        pattern = "\\b(case|default)\\b";
        count+=countOf(pattern,inputData);
        return count;
    }
    static int countOf(String pattern,String inputData){
        int count=0;
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(inputData);
        while(m.find()){
            count++;
        }
        return count;
    }
    static int findMatching(String inputData,int openingIndex){
        int i=openingIndex;
        int count=1;
        int matchingIndex = -1;
        while(true){
            if (inputData.charAt(i) =='{'){
                count++;
            }
            else if (inputData.charAt(i)=='}'){
                count--;
            }
            if (count==0){
                matchingIndex = i;
                break;
            }
            i++;
        }
        return matchingIndex;
    }
    public static void main(String[] args) {
	run("input3.c");
    }
}
