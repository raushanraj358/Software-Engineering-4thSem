import java.util.*;

public class Condition {

    String conditionName;
    ArrayList<String> rules;

    public Condition(String name, ArrayList<String> rule) {
        conditionName = name;
        rules = rule;
    }
}
