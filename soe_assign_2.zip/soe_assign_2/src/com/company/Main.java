package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;


public class Main {
    public static final String URL = "jdbc:mysql://localhost:3306/assign?useSSL=false";
    public static final String DRIVER = "com.mysql.jdbc.Driver";
    public static final String USERNAME = "debian-sys-maint";
    public static final String PSWD = "KpohHpUo0ERoxK8z";
    public static  Connection con;

    static String getInput(){
        String inp = null;
        try{
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            inp = br.readLine();
        }catch(IOException iex){
            iex.printStackTrace();
        }
        return inp;
    }
    static void displaOptioninitial(){
        System.out.println("admin");
        System.out.println("user");
        System.out.println("exit");
    }
    static void validateadmin() {
        System.out.print("enter username : ");
        String user = getInput();
        //System.out.println(user);
        System.out.print("enter password : ");
        String pass = getInput();
        //System.out.println(pass);
        if (user.toLowerCase().equals("admin") && pass.equals("admin")) runadmin();
        else {
            System.out.println("Wrong username or password");
        }
    }
    static void add_book(){
        System.out.print("enter book-id ");
        String id = getInput();
        System.out.print("enter book name");
        String bname = getInput();
        System.out.print("enter authors name");
        String aname = getInput();
        try{
            String query = "insert into Books(book_id,id,authors_name,book_name,status) VALUES(?,?,?,?,?)";
            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setString(1,null);
            pstmt.setString(2,id);
            pstmt.setString(3,aname);
            pstmt.setString(4,bname);
            pstmt.setString(5,"available");
            pstmt.execute();
            System.out.println("Succesfully inserted !");
        }catch(Exception e){
            e.printStackTrace();
            //System.out.println("Book Already Student Already present");
        }
    }
    static int displayBooks(ResultSet rs){
        try{
            if (!rs.next()){
                System.out.println("NO BOOK FOUND");
                return 0;
            }
            else {
                do {
                    System.out.println("ISBN : " + rs.getString("book_id"));
                    System.out.println("ID : " + rs.getString("id"));
                    System.out.println("BOOK NAME : " + rs.getString("book_name"));
                    System.out.println("AUTHORS NAME : " + rs.getString("authors_name"));
                    System.out.println("STATUS : " + rs.getString("status"));
                } while (rs.next());
                return 1;
            }
        }catch (Exception e){
            System.out.println("Some error occured");
            return 0;
        }
    }
    static int printBookDetail(String isbn){
        int num = Integer.parseInt(isbn);
        try{
            String query = "select * from Books where book_id = ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setInt (1,num);
            ResultSet rs = pst.executeQuery();
            return displayBooks(rs);
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }
    static void update_book(){
        System.out.print("enter ISBN number");
        String num = getInput();
        if (printBookDetail(num)==0) return;
        System.out.print("new book-id ");
        String id = getInput();
        System.out.print("new book name");
        String bname = getInput();
        System.out.print("new authors name");
        String aname = getInput();
        try{
            String query = "update Books set id=?,authors_name= ?, book_name = ? where book_id = ?";
            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setString(1,id);
            pstmt.setString(2,aname);
            pstmt.setString(3,bname);
            pstmt.setInt(4,Integer.parseInt(num));
            pstmt.execute();
            printBookDetail(num);
            System.out.println("Succesfully updated !");
        }catch(Exception e){
            e.printStackTrace();
            //System.out.println("Book Already Student Already present");
        }
    }
    static void delete_book(){
        System.out.print("Enter ISBN number");
        String num = getInput();
        try{
            String query = "select status from Books where book_id = ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setInt(1,Integer.parseInt(num));
            ResultSet rs = pst.executeQuery();
            rs.next();
            {
                String res = rs.getString(1);
                if (res.equals("issued"))
                {
                    System.out.println("CANNOT DELETE , BOOK ALREADY ISSUED");
                    return;
                }

            }
            query = "delete from Books where book_id = ? and status=?";
            pst = con.prepareStatement(query);
            pst.setInt(1,Integer.parseInt(num));
            pst.setString(2,"available");
            pst.execute();
            System.out.println("successfully deleted".toUpperCase());
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    static boolean checkNumber(String id){
        try{
            String query = "select count(book_id) from Issue_table where student_id = ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1,id);
            ResultSet rs = pst.executeQuery();
            rs.next();
            int num = Integer.parseInt(rs.getString(1));
            if (num<4) return true;
            else return false;
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("inside checkNumber");
            return false;
        }
    }
   static boolean checkstatus(String num){
        try{
            String query = "select status from Books where book_id = ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setInt(1,Integer.parseInt(num));
            ResultSet rs = pst.executeQuery();
            rs.next();
            String ans = rs.getString(1);

            if (ans.equals("available"))  return true;
            else return false;
        }catch(Exception e){
            System.out.println("Error inside checkStatus");
            return false;
        }
    }

    static void issue_book(){
        System.out.print("Enter Student id");
        String id = getInput();
        if (!checkNumber(id)) {System.out.println("CANNOT ISSUE MORE THAN 4 BOOKS");return;}
        System.out.print("Enter ISBN number");
        String num = getInput();
        if (!checkstatus(num)) {System.out.println("ALREADY ISSUED");return;}
        try {
            String query = "insert into Issue_table(book_id,student_id,issue_date) values(?,?,?)";
            String query1 = "update Books set status = ? where book_id = ?";
            PreparedStatement pst = con.prepareStatement(query);
            PreparedStatement pst1 = con.prepareStatement(query1);
            pst.setInt(1, Integer.parseInt(num));
            pst.setString(2, id);
            pst.setDate(3,new java.sql.Date(System.currentTimeMillis()));
            pst.execute();
            System.out.println("SUCCESSFULLY ISSUED");
            pst1.setString(1,"issued");
            pst1.setInt(2, Integer.parseInt(num));
            pst1.execute();
            System.out.println("SUCCESSFULLY UPDATED STATUS");
        }catch(Exception e){
            System.out.println("INSIDE ISSUE BOOK ERROR");
        }
    }
    static void return_book(){
        System.out.print("Enter Student id");
        String id = getInput();
        System.out.print("Enter ISBN number");
        String num = getInput();
        try{
            Date d  = new java.sql.Date(System.currentTimeMillis());

            String query = "select issue_date from Issue_table where book_id = ? and student_id=?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setInt(1,Integer.parseInt(num));
            pst.setString(2,id);
            ResultSet rs = pst.executeQuery();
            rs.next();
            Date currdate = rs.getDate(1);

            query = "delete from Issue_table where book_id = ? and student_id = ?";
            pst = con.prepareStatement(query);
            pst.setInt(1,Integer.parseInt(num));
            pst.setString(2,id);
            pst.execute();

            query = "update Books set status = ? where book_id = ?";
            pst = con.prepareStatement(query);
            pst.setString(1,"available");
            pst.setInt(2,Integer.parseInt(num));
            pst.execute();

            long diff = ((d.getTime()-currdate.getTime())/86400000);
            System.out.print("FINE : Rs ");
            if (diff>15) System.out.print((diff-15)*5);
            else System.out.print(0);
            System.out.println("\nSUCCESSFULLY RETURNED");
        }catch(Exception e){
            System.out.println("Inside return_book");
        }
    }
    static void view_details(){
        System.out.print("Enter Student ID");
        String id = getInput();
        try{
            String query = "select Books.book_id,Books.id,Books.book_name from Issue_table,Books where student_id = ? and Books.book_id=Issue_table.book_id";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1,id);
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
                System.out.println("ISBN :  " + rs.getInt(1) +" BOOK ID : "  + rs.getString(2) + "   " + "BOOK NAME : "+rs.getString(3));
            }
        }catch(Exception e){
            System.out.println("Inside View Details");
            //e.printStackTrace();
        }
    }
    static void runadmin() {
        while (true) {
            System.out.println("1 - add book");
            System.out.println("2 - update book");
            System.out.println("3 - delete book");
            System.out.println("4 - issue book");
            System.out.println("5 - return book");
            System.out.println("6 - view Student Profile");
            System.out.println("0 - exit");
            System.out.print(">");
            String input = getInput();
            if (input.equals("1")) {
                add_book();
            } else if (input.equals("2")) {
                update_book();
            } else if (input.equals("3")) {
                delete_book();
            } else if (input.equals("4")) {
                issue_book();
            } else if (input.equals("5")) {
                return_book();
            }else if (input.equals("6")){
                view_details();
            }else if (input.equals("0")) {
                break;
            }
        }
    }
    static void Searchbook(){
        System.out.print("enter ISBN number");
        String num = getInput();
        printBookDetail(num);
        System.out.println();
        return;
    }
    static void Checkstatusofbook(){
        System.out.println("Enter Student ID ");
        String id = getInput();
        try{
            String query = "select Books.book_id,Books.id,Books.book_name,Books.authors_name,Issue_table.issue_date from Books,Issue_table where student_id = ? and Books.book_id = Issue_table.book_id";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1,id);
            ResultSet rs = pst.executeQuery();
            Date curr = new java.sql.Date(System.currentTimeMillis());
            int fine;
            while (rs.next()){
                Date prev = rs.getDate(5);
                int diff = (int)((curr.getTime() - prev.getTime())/86400000);
                if (diff > 15) {
                    fine = 5*(diff-15);
                }
                else fine = 0;
                System.out.println("ISBN : " + rs.getInt(1));
                System.out.println("BOOK ID : "+ rs.getString(2));
                System.out.println("BOOK NAME : "+rs.getString(3));
                System.out.println("AUTHORS NAME : "+rs.getString(4));
                System.out.println("ISSUE DATE : "+prev);
                System.out.println("FINE : Rs "+fine +"\n");
            }
        }catch(Exception e){
            System.out.println("Inside CheckStatusofbook");
        }
    }
    static void runuser(){
        while (true) {
            System.out.println("1 - Search book");
            System.out.println("2 - Check Status Of Yourself");
            System.out.println("0 - exit");
            System.out.print(">");
            String input = getInput();
            if (input.equals("1")) {
                Searchbook();
            } else if (input.equals("2")) {
                Checkstatusofbook();
            } else if (input.equals("0")) {
                break;
            }
        }
    }

    static void runMain() {
        System.out.println("Type help for all commands");
        while (true) {
            System.out.print(">");
            String input = getInput();
            if (input.equals("help")) {
                displaOptioninitial();
            } else if (input.toLowerCase().equals("admin")) {
                validateadmin();
            } else if (input.toLowerCase().equals("user")) {
                  runuser();
            } else if (input.equals("exit")) {
                break;
            }
        }
    }
    public static void main(String[] args) {
            try{
                Class.forName(DRIVER);
                con = DriverManager.getConnection(URL,USERNAME,PSWD);
                System.out.println("Connection Succesfull");
                runMain();
                con.close();
            }catch(Exception e){
                e.printStackTrace();
            }

    }
}
