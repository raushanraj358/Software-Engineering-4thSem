use assign2;

create table if not exists Books(
	book_id int(255) AUTO_INCREMENT PRIMARY KEY,
	id varchar(255) NOT NULL,
	authors_name varchar(255) NOT null,
	book_name varchar(255) not null,
	status varchar(20) check (status="available" or status="issued"));

create table if not exists Student(
	id varchar(255) PRIMARY KEY,
	name varchar(255) not null
);
	
create table if not exists Issue_table(
	book_id int(255),
	student_id varchar(255),
	issue_date DATE not null,	
	foreign key (book_id) references Books(book_id),
	foreign key (student_id) references Student(id));

	 
